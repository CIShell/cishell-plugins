package edu.iu.sci2.visualization.bipartitenet.model;

public interface NodeProvider {
	Node getNodeById(int id);
}
