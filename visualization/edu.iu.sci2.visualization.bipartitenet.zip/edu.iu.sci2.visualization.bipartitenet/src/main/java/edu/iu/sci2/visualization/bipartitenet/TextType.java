package edu.iu.sci2.visualization.bipartitenet;

public enum TextType {
	TITLE, NODE_LABEL, LEGEND, FOOTER, HOW_TO_READ;
}
